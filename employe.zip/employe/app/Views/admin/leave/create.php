<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>


    <div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
        <div class="card ">
            <div class="card-header">
                <div class="d-flex w-100 justify-content-between">
                    <div class="col-auto">
                        <div class="card-title h4 mb-0 fw-bolder">Request Leave</div>
                    </div>
                    <div class="col-auto">
                        <a href="/admin/user/" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
                    </div>
                </div>
            </div>

            <div class="card-body mx-3">
                
                <form class="" action="/employee/leave/create" method="post" id="myForm" >
                	<div class="row">
                    <div class="col-sm-6 mb-3 form-group">
                        <label for="exampleFormControlInput1" class="form-label">Date apply</label>
                       <input type="date" name="dateapply" max="2024-03-31" min="2023-05-10" class="form-control" value="<?= set_value('dateapply');?>">
                    </div>
                   
				<div class="col-sm-6 form-group">
					  <label for="exampleFormControlTextarea1" class="form-label">Leave Type</label>
					<select class="form-control" id="job_status" name="job_status" onchange=''>
							<option>Leave type </otpion>
							<option value=1> Short Leave</option>
							<option value=2> Full Day Leave  </option>
							<option value=2> Halfday Leave </option>
						
						
							
					</select>
				</div>
				</div>
			
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Reason to leave</label>
                        <textarea class="form-control" id="floatingTextarea" name ="reasonleave" id="reasonleave" value="<?= set_value('reason_leave');?>" placeholder="Reason to leave"rows="2"></textarea>
                    </div>

                    <?php if (isset($validation)): ?>
                                <div class="col-12">
                                    <div class="alert alert-danger" role="alert">
                                        <?= $validation->listErrors(); ?>
                                    </div>
                                </div>
                    <?php endif; ?>


                    <div class="col-12 col-sm-12">
                        <input type="submit" class="btn btn btn-primary bg-gradient border rounded-0" value="Save User" id="sbmitBtn">
                   </div>
                </form>

            </div>

        </div>
    </div>
    


<?= $this->endSection() ?>



