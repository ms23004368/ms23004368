<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
	<?php if (session()->get('sucess')): ?>
	<div class="alert alert-success" role="alert">
		<?= session()->get('sucess')?>
	</div>
	<?php endif; ?>


<div class="card shadow">

<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">  Add  Salary</div>
            </div>
            
           <div class="col-auto">
                <a href="/admin/payroll/view" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
            </div>
        </div>

    </div>

<div class="card-body">		
		<form class="" action="/admin/payroll/create" method="post" id="myForm" enctype="multipart/form-data" >
			<div class="row">
				<div class="col-12 col-sm-6 mt-3">
					<div class="form-group  ">
								
								   <select class="form-select" aria-label="Default select example" name="empno">
								 <?php if ($user) :?>
								 <?php foreach($user as $usr){ ?>
								  
								  <option value=<?= $usr['empno'] ?>> <?= $usr['firstname'] ?> <?= $usr['lastname'] ?> </option>
								 
								 <?php } ?>
								 <?php else:?>
								 <option> No Emoplyees </p>
								 <?php endif;?>
								</select>
						
						</div>
						<small> select employee name form the list </small>
					</div>


						<div class="col-12 col-sm-6 mt-3 mb-3">
						<div class="form-group">
							
							 <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
							
						</div>
						<small>salary payment date </small>
						</div>


					<div class="col-sm-4 mb-3 mt-3">
							<div class="form-group">
								
							   
     							<div class="form-outline" ">
    							<input  type="text" id="OT" name="allaownce" class="form-control" placeholder="Allowances" value="<?= set_value('allaownce');?>"/>
							</div>
							<small> add allowances to calucate gross salary </small>
						</div>
					</div>

					<div class="col-sm-4 mb-3 mt-3">
							<div class="form-group">
								
							
     							<div class="form-outline" ">
    							<input  type="text" id="OT" name="deduction" class="form-control" placeholder="Deduction" value="<?= set_value('deduction');?>"/>
							</div>
							<small> add deduction to calucate net salary </small>
						</div>
					</div>
				<div class="col-12 col-sm-3 mb-3 mt-3">
				<div class="form-group">
					<select class="form-control" id="qulification" name="pay_period" onchange=''>
							<option> Paid Salary </otpion>
							<option value=January">January</option>
							<option value="February">February</option>
							<option value="March">March</option>
							<option value="April">April</option>
							<option value="May">May</option>
							<option value="June">June</option>
							<option value="July">July</option>
							<option value="August">August</option>
							<option value="September">September</option>
							<option value="October">October</option>
							<option value="November">November</option>
							<option value="December">December</option>
					</select>
				</div>
				<small> select the month for salary  </small>
			</div>






						<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role="alert">
								<?= $validation->listErrors(); ?>
							</div>
						</div>
						<?php endif; ?>
					
					
			<div class="col-12 col-sm-12 mt-3">
					 <input type="submit" class="btn btn-primary float-right " value="Calculate Salary">
			</div>
				</form>
</div>
</div>
</div>

<?= $this->endSection() ?>



