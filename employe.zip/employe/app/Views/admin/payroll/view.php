<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">

<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">PayRoll</div>
            </div>
          

            <div class="col-auto">
                <a href="/admin/payroll/create" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Add Salary</a>
            </div>
               
            
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">
<!-- Search Bar --> 
<div class="">
    <input id="myInput" type="text" placeholder="Search.." class="form-control" >

<small> you can filter users by typing any word in the table </small>
</div>




</br>
<?php if ($users) :?>
 <table class="table table-bordered table-striped">
<thead class="thead-light bg-warning">
<tr>
      <th> Emp No. </th>
      <th> Emp Name </th>
    
      <th> Paid Month </th>
      <th> Basic Salary </th>
      <th> Allowance </th>
      <th> Deducton  </th>
      
      <th> Gross Salary </th>
      <th> Net Salary </th>
      <th> Action </th>

</tr>
</thead>
<tbody id="myTable">
<?php foreach($users as $user){ ?>
<tr>
  
  <td> <?=$user['empno'] ?></td>
  <td> <?=$user['firstname']?> <?=$user['lastname']?>    </td>
 
  <td> <?=$user['pay_period'] ?></td>
  <td> <?=$user['basic_salary'] ?></td>
  <td> <?=$user['allaownce'] ?></td>
  
   <td> <?=$user['deduction'] ?></td>
  
   <td> </td>
   <td></td>
  <td>
   

<a href="/edit_user/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users">
<i class="fa-solid fa-money-bill" style="color: #3bff05;"></i></a><br> 
<a href="/edit_user/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users">
<i class="fa-solid fa-pen-to-square" style="color: #efbc06;"></i></a> <br>
<a href="/edit_user/<?=$user['id'];?>">
<i class="fa-solid fa-trash" style="color: #ff4000;"></i>

</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php else:?>
<p> There are no courses Available for apply  </p>
<?php endif;?>
</div>




</td>
</tr>
</tbody>
</table>
</div>
</div>





<?= $this->endSection() ?>



