<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">



<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">Reports </div>
            </div>
         
        </div>
    </div>

<div class="card-body">
       
<div class="row">
  <div class="col-12 mb-3">
<div class="card text-center">
 
  
    <small class="card-text  ">This software can generate different types of reports, such as performance, attendance, and salary reports </small>
    
  </div>
</div>
  </div> 
<div class="row">

<div class="accordion" id="accordionPanelsStayOpenExample">

  <div class="accordion-item ">
    <h2 class="accordion-header bg-sucess " id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed bg-success text-white" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
        Employee Attendance
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        
                      <div class="row">
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>start date  </small>
                </div>      

     
    
       
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>end date</small>
                </div>  

                   <div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Print</a>
            </div><div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Export</a>
            </div>
        
                </div>     

      </div>
    </div>
  </div>
   <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed bg-info text-white" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
        Employee Salary
      </button>
    </h2>
  
    
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
       <small>apply date for view report</small>
         <form action="/admin/user/profile/create/" method="post" enctype="multipart/form-data">
                <div class="row">
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>start date  </small>
                </div>      

     
    
       
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>end date</small>
                </div>  

                   <div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Print</a>
            </div><div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Export</a>
            </div>
        
                </div>    

  </form>
  </div>
</div>
</div>

<div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed bg-secondary text-white" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseperfromance" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
        Employee Performance
      </button>
    </h2>
  
       <div id="panelsStayOpen-collapseperfromance" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
       <small>apply date for view report</small>
         <form action="/admin/user/profile/create/" method="post" enctype="multipart/form-data">
                <div class="row">
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>start date  </small>
                </div>      

     
    
       
                <div class="col-6 col-sm-6">
                <div class="form-group">
                    
                     <input type="date" name="date_of_birth" max="" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
                    
                </div>
                <small>end date</small>
                </div>  

                   <div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Print</a>
            </div><div class="col-auto">
                <a href="<?= base_url('Main/user_add') ?>" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Export</a>
            </div>
        
                </div>    

  </form>
  </div>
</div>
   
  </div>
</div>
</div>
</div>
</div

 


<?= $this->endSection() ?>



