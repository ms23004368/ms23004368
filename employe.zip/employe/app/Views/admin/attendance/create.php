<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>

<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">Add Attendance</div>
            </div>
            <div class="col-auto">
                <a href="/admin/attendance/view" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
            </div>
        </div>
    </div>



<div class="card-body">
    <div class="row">			
		<form class="" action="/admin/attendance/create" method="post" id="myForm" enctype="multipart/form-data">
			<div class="row">
				<div class="col-6 col-sm-6">
					<div class="form-group  ">
								<label for="startDate">Employee Name</label>
								   <select class="form-select" aria-label="Default select example" name="empno" value="<?= set_value('allaownce');?>">
								 <?php if ($user) :?>
								 <?php foreach($user as $usr){ ?>
								  
								  <option value=<?= $usr['empno'] ?>> <?= $usr['firstname'] ?> <?= $usr['lastname'] ?> </option>
								 
								 <?php } ?>
								 <?php else:?>
								 <option> No Emoplyees </p>
								 <?php endif;?>
								</select>
						
						</div>
					</div>
				
					
					<div class="col-6 col-sm-6  mb-3">
						<div class="form-group">
							 <label for="startDate">Select the Date</label>
            <input id="startDate" class="form-control" type="date" name="dateofattend" />
            <span id="startDateSelected"></span>
						
						</div>
					</div>
					<div class="col-6 col-sm-6  mb-3">
					<div class="form-group  ">
								<label for="startDate">Attendance Type</label>
								   <select class="form-select" aria-label="Default select example" name="emp_status" 
								   value="<?= set_value('emp_status');?>"/>>
								
								  
								  <option value=1> Leave </option>
								  <option value=2> Lalfday </option>
								  <option value=3> Fullday </option>
								</select>
						
						</div>
					</div>
								
								<div class="col-sm-6 mb-3">
							<div class="form-group">
								
							   <label for="startDate">Select OT</label>
     							<div class="form-outline" ">
    							<input type="text" id="OT" name="OT" class="form-control" value="<?= set_value('allaownce');?>"/>
							</div>
						</div>

						
						</div>
					</div>

						
						<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role="alert">
								<?= $validation->listErrors(); ?>
							</div>
						</div>
						<?php endif; ?>
					</div>
					<hr>

					<div class="col-12 col-sm-12">
					 	<input type="submit" value="Save"  class="btn btn btn-primary bg-gradient border rounded-0">

                
            		</div>

					</div>
				</form>
</div>
</div>

<?= $this->endSection() ?>



<script type="text/javascript">
   
"let startDate = document.getElementById('startDate')\nlet endDate = document.getElementById('endDate')\n\nstartDate.addEventListener('change',(e)=>{\n  let startDateVal = e.target.value\n  document.getElementById('startDateSelected').innerText = startDateVal\n})\n\nendDate.addEventListener('change',(e)=>{\n  let endDateVal = e.target.value\n  document.getElementById('endDateSelected').innerText = endDateVal\n})  "

</script>
