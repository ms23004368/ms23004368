<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">Attendance</div>
            </div>
            <div class="col-auto">

<a type="button" class="btn btn-primary bg-gradient border rounded-0" href="create"><i class="far fa-plus-square"></i> Add Attendance</a>
               
            </div>
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">
   <div class="row">
   <div class="col-12">
   

</div>
</div>


<div class="row">
<div class="col-12">
 <div>
<br>
<input class="form-control" id="myInput" type="text" placeholder="Search..">
<small> you can filter users by typing any word in the table </small>
</div>




</br>
<?php if ($attendances) :?>
 <table class="table table-bordered table-striped table table-hover">
<thead class="thead-light bg-warning">
<tr>
      <th> ID# </th>
      <th> Empnoyee No </th>
      <th> User Full Name  </th>
      
      <th> Attendance date </th>

      <th> Work Status</th>
      <th> OT hrs </th>
    <th> Action </th>
    
      

</tr>
</thead>
<tbody id="myTable">
<?php foreach($attendances as $attend){ ?>
<tr>
  <td> <?= $attend['a_id']?>  </td>
  <td> <?= $attend['empno']+19000?>  </td>
  <td> <?=$attend['firstname']?>  <?=$attend['lastname'] ?>  </td>
  
  <td> <?=$attend['dateofattend']?>  </td>

  <td> 
  <?php if($attend['emp_status']==1) : ?>
    <small class="badge rounded-pill bg-danger"> Leave </small>

  <?php elseif($attend['emp_status']==2):?>

    <small class="badge rounded-pill bg-warning text-dark"> Half day</small>

  <?php else:?>
    <small class="badge rounded-pill bg-success">Full day</small>

<?php endif;?>
</td>
<td> <?= $attend['OT'] ?> </td>

 <td> 
<a href="#">
 <i class="fa-solid fa-users-viewfinder fa-fade" style="color: #3169c9;"></i> 
</a>
<a href="#">
<i class="fa-solid fa-pen-to-square" style="color: #ddb627;"></i> 
</a>
<a href="#">
<i class="fa-solid fa-trash" style="color: #ff4000;"></i> </td>
</a>
   
    
 

</tr>
<?php } ?>
</tbody>
</table>
<?php else:?>
<p> There are no courses Available for apply  </p>
<?php endif;?>
</div>
</div>
</div>
</div>
</div>






<?= $this->endSection() ?>


