<?php
  $uri = service('uri');

 ?>



<?php if ((session()->get('isLogedIn')) && (session()->get('loginUser')=='Admin')): ?>
<div class="card">
<div class="card-header">
   <a href="/" class="d-flex align-items-center  link-dark text-decoration-none">
     
      <span class="fs-5 fw-semibold"><i class="fa-solid fa-screwdriver-wrench " ></i> Admin Menu</span>
    </a>
</div>
<div class="card-body">
<ul class="navbar-nav nav nav-pills flex-column mb-auto">
 <li class="nav-item <?=($uri->getSegment(1)=='dashboard' ? 'active' : null )?>">

   <a class="nav-link " href="/admin/dashboard"><i class="fa-solid fa-gauge"></i>  <span class="ms-3"> Dashboard </span> <span class="sr-only">(current)</span></a>
   
 </li>
 <li class="nav-item <?=($uri->getSegment(1)=='user' ? 'active' : null )?>">
   <a class="nav-link" href="/admin/user"><i class="fa-solid fa-users"></i> <span class="ms-2"> Mange Users</span></a>
 </li>
 <li class="nav-item <?=($uri->getSegment(1)=='attendance' ? 'active' : null )?>">
   <a class="nav-link" href="/admin/attendance/view"><i class="fa-solid fa-clipboard-user"></i><span class="ms-3"> Attendance</span></a>
 </li>
 <li class="nav-item <?=($uri->getSegment(1)=='payroll' ? 'active' : null )?>">
   <a class="nav-link" href="/admin/payroll/view"><i class="fa-brands fa-cc-amazon-pay"></i> <span class="ms-2"> Manage Payroll</span></a>
 </li>
 <li class="nav-item <?=($uri->getSegment(1)=='report' ? 'active' : null )?>">
   <a class="nav-link" href="/admin/report/view"><i class="fa-solid fa-file-waveform"></i> <span class="ms-3"> Reports</span></a>
 </li>
 
</ul>

<ul class="navbar-nav ml-auto">
 <li class="nav-item ">
   <a class="nav-link" href="/logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="ms-3"> Logout</span></a>
 </li>
</ul>

</div>
    
</div>

<?php elseif((session()->get('isLogedIn')) && (session()->get('loginUser')=='Employee')):?>
<div class="card">
<div class="card-header">
   <a href="/" class="d-flex align-items-center pb-3  link-dark text-decoration-none">
     
      <span class="fs-5 fw-semibold">Employee Menu</span>
    </a>
</div>
<div class="card-body">
<ul class="navbar-nav">
 <li class="nav-item <?=($uri->getSegment(1)=='dashboard' ? 'active' : null )?>">
   <a class="nav-link" href="/employee/dashboard"><i class="fa-solid fa-gauge"></i>  <span class="ms-3"> Dashboard<span class="sr-only">(current)</span></a>
 </li>


 <li class="nav-item <?=($uri->getSegment(1)=='leave' ? 'active' : null )?>"">
   <a class="nav-link" href="/employee/leave/view"><i class="fa-solid fa-person-walking-arrow-right"></i><span class="ms-3">Request leave</span></a>
 </li>

 <li class="nav-item <?=($uri->getSegment(1)=='history' ? 'active' : null )?>"">
   <a class="nav-link" href="/employee/history/view"><i class="fa-solid fa-clock-rotate-left"></i> <span class="ms-3">  History</a>
 </li>

</ul>

<ul class="navbar-nav ml-auto">
 <li class="nav-item ">
   <a class="nav-link" href="/logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="ms-3"> Logout</a>
 </li>
</ul>
</div>
</div>

<?php elseif((session()->get('isLogedIn')) && (session()->get('loginUser')=='Manager')):?>
<div class="card">
<div class="card-header">
   <a href="/" class="d-flex align-items-center pb-3  link-dark text-decoration-none">
     
      <span class="fs-5 fw-semibold">Manager Menu</span>
    </a>
</div>
<div class="card-body">
<ul class="navbar-nav">
 <li class="nav-item <?=($uri->getSegment(1)=='dashboard' ? 'active' : null )?>">
   <a class="nav-link" href="/manager/dashboard"><i class="fa-solid fa-gauge"></i><span class="ms-3">Dashboard <span class="sr-only">(current)</span></a>
 </li>
 
 <li class="nav-item <?=($uri->getSegment(1)=='leaverequest' ? 'active' : null )?>"">
   <a class="nav-link" href="/manager/leave/leaverequest"><i class="fa-solid fa-person-walking-arrow-right"></i><span class="ms-2">Leaves</span></a>
 </li>
 

 <li class="nav-item <?=($uri->getSegment(1)=='Reports' ? 'active' : null )?>"">
   <a class="nav-link" href="/manager/reports/view"><i class="fa-solid fa-file-waveform"></i> <span class="ms-3"> Reports</span></a>
 </li>
 
</ul>

<ul class="navbar-nav ml-auto">
 <li class="nav-item ">
   <a class="nav-link" href="/logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="ms-2">Logout</span></a>
 </li>
</ul>

</div>
</div>
<?php else:?>
<ul class="navbar-nav">

<li class="nav-item <?=($uri->getSegment(1)=='' ? 'active' :null )?>"">
 <a class="nav-link" href="/"><i class="fa-solid fa-right-from-bracket"></i> <span class="ms-3">Login</span></a>
</li>

</ul>

<?php endif;?>
