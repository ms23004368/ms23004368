<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>

<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder"></div>
            </div>
            <div class="col-auto">
                <a href="/admin/user/create" class="btn btn btn-primary bg-gradient border rounded-0"><i class="fa-solid fa-user-pen fa-beat-fade" style="color: #ffffff;"></i> Edit</a>
            </div>
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">


	

<h4> Basic info </h4>
<ul class="list-group">
  <a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between"><span>Profile picture</span><span><img src="#"> </span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between">Name<span></span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between flex-wrap ">Birthday<span></span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between ">Gender<span>Male </span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between ">Password<span>**** <small>Last change</small> </span><span><h4>></h4></span></a>

</ul>

<h4> Contact info </h4>
<ul class="list-group">
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between">E-mail<span>Male </span> <span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between">Phone<span>077305111 </span> </span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between">Home Phone<span>011122444</span><span><h4>></h4></span></a>
	<a href="#" class="list-group-item list-group-item-action list-group-item-light d-flex justify-content-between">Address<span>386/B,Idigaslanda, Pamunugama</span><span><h4>></h4></span></a>

</ul>
</div>
<?= $this->endSection() ?>
