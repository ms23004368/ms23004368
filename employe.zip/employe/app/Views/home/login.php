<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/font-awesome.min.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/bootstrap-icons.css');?>" />
<script src="<?php echo base_url('js/jquery.min.js');?>"> </script>
<link rel="stylesheet" href="<?php echo base_url('css/style.css');?>" />
</head>

<style>
body{
}
.bg{

	background-image:url("img/home/loginbg.jpg");
	 opacity:.9;

	 background-position: center;
	 background-repeat: no-repeat;
	 background-attachment: fixed;
	 background-size: cover;
	 position: relative;

 	 height: 100vh;
}
.op{
	  opacity: 0.6;
}
.space1{
	margin-left: 150px;
}
.space2{
	margin-left: 50px;
	margin-top: 150px;
}
.marginb{
	margin-top: 100px;
}
</style>
</head>
<body>

<div class="container-fluid bg">
	<div class="row">
    <div class="contaner col-12 text-center">
        <h1> Votext International </h1> 
       
        <hr>

    </div>
    </div>

 <div class="row">

        <div class="col-6 ">
           <img src="img/vortex.jpeg" alt="..." />
        </div>
    <div class="col-6">
    <div
      class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 mt-5 pt-3 pb-3 bg-white from-wrapper"
    >
      <div class="container">
      	<?php if (session()->get('success')): ?>
			<div class="alert alert-success" role="alert">
					<?= session()->get('success')?>
			</div>
		<?php endif; ?>
        <h3>Signin</h3>
        <hr />

         <form class="login" action="/login" method="post">
         	<div class ="row">
          <div class="col-12 col-sm-12 p-2">
          <div class="form-group">
            <label for="email">Email address</label>
            <input type="text" class="p-2" placeholder="Login E-mail" name ="email" id="email">
          </div>
        </div></div>
        <div class ="row">
						<div class="col-12 col-sm-12">
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="p-2"  placeholder="Login Password" name ="password" id="passwd">
          </div>
         	</div></div>

          <div class="row">
          	<div class="form-group">
          	<label></label>
            <div class="col-12 col-sm-4">
              <input type="submit" class="btn btn-primary" value="Login"           
               </div>

            </div>
             <small> <a href="/change_password">forgot password </a> </small>
          </div>
        </form>
        <?php if (isset($validation)): ?>
            <div class="col-sm-12">
                <div class="alert alert-danger" role="alert">
                  <?= $validation->listErrors(); ?>
                </div>
            </div>

      <?php endif; ?>
      </div>
    </div>
  </div>






<?= $this->include('templates/footer') ?>
