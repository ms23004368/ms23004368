<?php
namespace App\Controllers\BaseClasses;
use App\Controllers\BaseController;

use CodeIgniter\I18n\Time;
use App\Models\AttendanceModel;
use App\Models\UserModel;

$pager = \Config\Services::pager();

class Attendance extends BaseController
{

	private $model ;
	protected $logger;
	
	
	public function __construct()
	{
		helper('form');
		$this->model = new AttendanceModel();
		$this->user_model= new UserModel();

		helper('date');
		
        
	}

    public function index()
    {
       // $data['users']= $this->model->findAll()->paginate(5);
	   // $this->orderBy('id','DESC')->findAll()
		
		$data['attendances'] = $this->model->get_attendace_users(); 
		//$this->model->orderBy('id','DESC')->paginate(5);
		//$data['pager'] = $this->model->pager;
      $data['title']="Users";
		//$this->logger->info('Retrieved all users from the database.', $data['attendance']);
        return view("admin/attendance/view",$data);
    }


    public function create()
	    {
	    	$data = [];

		$data['user'] = $this->user_model->get_users_empno();
			if ($this->request->getMethod()=='post')
				{
					$rules=
						[
							'empno' => 'required',
							'dateofattend'=> 'required',

							'emp_status'=> 'required|',
							'OT'=> 'required',
							
						// 'emp_status'=>
						// 	[
						// 		'label' => "Leave Validation",
						// 		'rules'=> 'is_allowed_status[empno]',
						// 		'errors'=> [
						// 										'is_allowed_status'=>"You have acquired all leave for this month "
						// 							 ]
						// 	]

						];
					if (! $this->validate($rules))
						{
							$data['validation']= $this->validator;
						}
					else
						{
							$newdata =
							[
								'empno' => $this->request->getVar('empno'),
								'dateofattend' => $this->request->getVar('dateofattend'),
								'emp_status' => $this->request->getVar('emp_status'),
								'OT' => $this->request->getVar('OT'),
								
							];
							
							$this->model->save($newdata);
							
							$message = "Sucessfully add attenance" ;
							$session= session();
							$session->setFlashdata('sucess', $message);
							return redirect()->to('/admin/attendance/view');
						}
				}
                return view('admin/attendance/create',$data);
	}
        




	public function edit_attendance($id=null)
	{
					$data=[];
					if ($this->request->getMethod()=='post')
					{
						$rules=[
							'firstname'=> 'required|min_length[3]|max_length[20]',
							'lastname'=> 'required|min_length[3]|max_length[20]',
								'email'=> 'required|min_length[5]|max_length[50]|valid_email',
						];
						if ($this->request->getPost('password')!=''){
							$rules['password']= 'required|min_length[3]|max_length[20]';
							$rules['cpassword']= 'matches[password]';
						}
					 if (! $this->validate($rules)){
						$data['validation']= $this->validator;
					}
					 else
						{
						$newdata =
						[
									'id' => $id,
									'role' => $this->request->getPost('role'),
									'username'=>$this->request->getPost('username'),
									'firstname' => $this->request->getPost('firstname'),
									'lastname' => $this->request->getPost('lastname'),
									'email' => $this->request->getVar('email'),
									'slug' => url_title($this->request->getVar('email')),
									'update' => date('Y-m-d H:i:s',now()),
						];
			if ($this->request->getPost('password')!=''){
				$newdata['password']= $this->request->getPost('password');
			}
						$this->model->save($newdata);
						session()->setFlashdata('success', 'Sucessfully Updated');
						return redirect()->to('/user');
					 }
					}
					$data['user']=$this->model->where('id',$id)->first();
					return view("/users/edit",$data);
}


	
}
