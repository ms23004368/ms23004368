<?php
namespace App\Controllers\BaseClasses;
use App\Controllers\BaseController;

use CodeIgniter\I18n\Time;
use App\Models\UserModel;
use App\Models\UserProfileModel;
$pager = \Config\Services::pager();

class Users extends BaseController
{

	private $model ;
	protected $logger;
	
	
	public function __construct()
	{
		helper('form');
		$this->model = new UserModel();
		$this->employee= new UserProfileModel();
		helper('date');
		
        
	}

    public function index()
    {
      
		
		$data['users'] = $this->model->orderBy('id','DESC')->paginate(5);
		$data['pager'] = $this->model->pager;
        $data['title']="Users";
		$this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("admin/users/view",$data);
    }


   


    public function create()
    {
		$data=[];
			if ($this->request->getMethod()=='post')
				{
					$rules=
						[
							'firstname'=> 'required|min_length[3]|max_length[20]',
							'lastname'=> 'required|min_length[3]|max_length[100]',
							'email'=> 'required|min_length[5]|max_length[50]|valid_email|is_unique[users.email]',
							'password'=> 'required|min_length[8]|max_length[255]',
							'mobile'=> 'required|min_length[10]|max_length[10]|valid_phone_number[mobile]',
							'cpassword'=>[
									'label' => 'Confirm Password',
									'rules'=> 'matches[password]',
									'errors'=> [
										'matches'=>' Confirm password should be match with password'
											 ]
									],
							
						];
					if (! $this->validate($rules))
						{
							$data['validation']= $this->validator;
						}
					else
						{
							$newdata =
							[
								'email' => $this->request->getVar('email'),
								'password' => $this->request->getVar('password'),
								'role' => $this->request->getVar('role'),
								'firstname' => $this->request->getVar('firstname'),
								'lastname' => $this->request->getVar('lastname'),
								'mobile' => $this->request->getVar('mobile'),
								'slug' => url_title($this->request->getVar('email')),
								
							];
							$myTime = new Time('now');
							$this->model->save($newdata);
							$time = Time::parse($myTime);
							
							
							$message = "User created successfully";
							$session= session();
							$session->setFlashdata('sucess', $message);
							return redirect()->to('/admin/user');
						}
				}
                return view('admin/users/create',$data);
	}
        




	public function edit_user($id=null)
	{
					$data=[];
					if ($this->request->getMethod()=='post')
					{
						$rules=[
							'firstname'=> 'required|min_length[3]|max_length[20]',
							'lastname'=> 'required|min_length[3]|max_length[20]',
								'email'=> 'required|min_length[5]|max_length[50]|valid_email',];

						if ($this->request->getPost('password')!=''){
											$rules['password']= 'required|min_length[3]|max_length[20]';
											$rules['cpassword'] = 'matches[password]';
										}
					 if (! $this->validate($rules)){
						$data['validation']= $this->validator;
					}
					 else
						{
						$newdata =
						[
									'id' => $id,
									'role' => $this->request->getPost('role'),
									'username'=>$this->request->getPost('username'),
									'firstname' => $this->request->getPost('firstname'),
									'lastname' => $this->request->getPost('lastname'),
									'email' => $this->request->getVar('email'),
									'slug' => url_title($this->request->getVar('email')),
									'update' => date('Y-m-d H:i:s',now()),
						];
			if ($this->request->getPost('password')!=''){
				$newdata['password']= $this->request->getPost('password');
			}
						$this->model->save($newdata);
						session()->setFlashdata('success', 'Sucessfully Updated');
						return redirect()->to('/user');
					 }
					}
					$data['user']=$this->model->where('id',$id)->first();
					return view("/users/edit",$data);
}





    public function create_profile($id)
    {
    	$data=[];
    	
    	$data['user'] = $this->model->getuser_from_id($id);
    	$data['empno']= $this->model->get_user_empno($id);

		
			if ($this->request->getMethod()=='post')
				{
					$rules=
						[
							'date_of_birth'=> 'required|min_length[3]|max_length[20]',
							'appointdate'=> 'required|min_length[3]|max_length[100]',
							'depatment'=> 'required|min_length[5]|max_length[50]',
							'nationalid' => 'required|min_length[10]|max_length[12]|is_unique[user_profile.nationalid]',
							'address' => 'required',
							'contact_person' => 'required',
							'emagency_contact' => 'required',
							'qulifications' => 'required',
							'job_status' => 'required',	
							'basic_salary' => 'required',
							'appointdate' => 'required',
							'depatment' => 'required',	
							'designation' => 'required',
							'empno' => 'required|is_unique[user_profile.empno]',

			
							
						];
					if (! $this->validate($rules))
						{
							$data['validation']= $this->validator;
						}
					else
						{
							$newdata =
							[
								'empno' => $data['empno'],
								'uid' => $id,
								'date_of_birth' => $this->request->getVar('date_of_birth'),
								'appointdate' => $this->request->getVar('appointdate'),
								'depatment' => $this->request->getVar('depatment'),
								'gender'=>1, //$this->request->getVar('gender'),
								'qulifications' => $this->request->getVar('qulifications'),
								'nationalid' => $this->request->getVar('nationalid'),
								'basic_salary' => $this->request->getVar('basic_salary'),
								
								'job_status' => $this->request->getVar('job_status'),
								'experience' => $this->request->getVar('experience'),
								'address' => $this->request->getVar('address'),
								'contact_person' => $this->request->getVar('contact_person'),
								'emagency_contact' => $this->request->getVar('emagency_contact'),
								'designation' => $this->request->getVar('designation'),
								

								

								

							];
							
							
							$this->employee->save($newdata);
							$this->model->employee_activated($newdata['uid']);
						
							
							
							$message = "Sucessfully regisred an employee ";
							$session= session();
							$session->setFlashdata('sucess', $message);
							return redirect()->to('/admin/user');
						}
				}
                return view('admin/users/profile/create',$data);
	}


 public function edit_profile($id)
    {
    	$data=[];
    	
    	$data['user'] = $this->model->getuser_from_id($id);

		
			if ($this->request->getMethod()=='post')
				{
					$rules=
						[
							'date_of_birth'=> 'required|min_length[3]|max_length[20]',
							'appointdate'=> 'required|min_length[3]|max_length[100]',
							'depatment'=> 'required|min_length[5]|max_length[50]',
							'nationalid' => 'required|min_length[10]|max_length[12]|is_unique[user_profile.nationalid]',
							'address' => 'required',
							'contact_person' => 'required',
							'emagency_contact' => 'required',
							'qulifications' => 'required',
							'job_status' => 'required',	
							'basic_salary' => 'required',
							'appointdate' => 'required',
							'depatment' => 'required',	
							'designation' => 'required',
							'empno' => 'required|is_unique[user_profile.empno]',

			
							
						];
					if (! $this->validate($rules))
						{
							$data['validation']= $this->validator;
						}
					else
						{
							$newdata =
							[
								'uid' => $id,
								'date_of_birth' => $this->request->getVar('date_of_birth'),
								'appointdate' => $this->request->getVar('appointdate'),
								'depatment' => $this->request->getVar('depatment'),
								'gender'=>1, //$this->request->getVar('gender'),
								'qulifications' => $this->request->getVar('qulifications'),
								'nationalid' => $this->request->getVar('nationalid'),
								'basic_salary' => $this->request->getVar('basic_salary'),
								
								'job_status' => $this->request->getVar('job_status'),
								'experience' => $this->request->getVar('experience'),
								'address' => $this->request->getVar('address'),
								'contact_person' => $this->request->getVar('contact_person'),
								'emagency_contact' => $this->request->getVar('emagency_contact'),
								'designation' => $this->request->getVar('designation'),
								

								

								

							];
							
							
							$this->employee->save($newdata);
							$this->model->employee_activated($newdata['uid']);
						
							
							
							$message = "Sucessfully regisred an employee ";
							$session= session();
							$session->setFlashdata('sucess', $message);
							return redirect()->to('/admin/user');
						}
				}
                return view('users/profile/create',$data);
	}

	public function view_user_profiels($id)
	{
		
        $data['employee'] = $this->model->get_user_by_id($id);
        
        $this->logger->info('Retrieved all users from the database.', $data['employee']);
        return view("admin/users/profile/view",$data);
	}





	public function user_chagne_password()
				{
					$data=[];
					if ($this->request->getMethod()=='post')
					{
						$rules=[
							'email' => 'required',
							'current_password'=> 'required|is_password_exist[current_password]',
							'password'=> 'required|min_length[3]|max_length[20]',
							'cpassword'=> 'matches[password]',
						];

					 if (! $this->validate($rules)){
						$data['validation']= $this->validator;
					}
					 else
						{
						$newdata =
						[
									'user_id_pk' => session()->get('id'),
									'password'=> $this->request->getVar('password'),
									'update' => date('Y-m-d H:i:s',now()),
									'lastchange' => date('Y-m-d H:i:s',now()),
						];
						$this->model->save($newdata);
						$user= 	$this->model->where('email',$this->request->getVar('email'))
													->first();
							$this->setUserSession($user);
						session()->setFlashdata('success', 'Sucessfully change password');
						return redirect()->to('/dashboard');
					 }
				 }
				 		$data['title']= "Change Password";
						$data['user']=$this->model->where('id',session()->get('id'))->first();
					return  view("home/change_password",$data);
				}


	public function activate_user($id)
			{
					session()->setFlashdata('success', 'Sucessfully activated');
					printf("hi it was came");
					$this->model->change_status($id,$status=0,);
					return redirect()->to('/admin/user');
				}
	public function deactivate_user($id)
			{
				session()->setFlashdata('success', 'Sucessfully deactivated');
				$this->model->change_status($id,$status=1);
				return redirect()->to('/admin/user');
			}

		public function employee_user_history()
			{
				$data['user'] = [session()->get('firstname'),session()->get('lastname')];
				return  view("employee/emp_history_view",$data);
			}




        
}
