<?php
namespace App\Controllers\BaseClasses;
use App\Controllers\BaseController;

use CodeIgniter\I18n\Time;
use App\Models\UserModel;
use App\Models\PayrollModel;
use App\Models\AttendanceModel;
$pager = \Config\Services::pager();

class Payroll extends BaseController
{

	private $model ;
	protected $logger;
	
	
	public function __construct()
	{
		helper('form');
		$this->model = new UserModel();
		$this->payroll_model = new PayrollModel();
		$this->attendance_model = new AttendanceModel();
		helper('date');
		
        
	}

    public function index()
    {
       // $data['users']= $this->payroll_model->findAll()->paginate(5);
	   // $this->orderBy('id','DESC')->findAll()
	
        
		$data['users'] = $this->payroll_model->get_payments_users(); //orderBy('p_id','DESC')->paginate(5);
		//$data['pager'] = $this->payroll_model->pager;
        $data['title']="Users";
		//$this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("admin/payroll/view",$data);
    }


    public function create()
    {
		$data = [];

		$data['user'] = $this->model->get_users_empno();
			if ($this->request->getMethod()=='post')
				{
					$rules=
						[
							'empno'=> 'required',
							'allaownce'=> 'required|min_length[1]|max_length[100]',
							'deduction'=> 'required|min_length[1]|max_length[50]',
							'pay_period'=> 'required',
							
						];
					if (! $this->validate($rules))
						{
							$data['validation']= $this->validator;
						}
					else
						{
							$newdata =
							[
								'empno' => $this->request->getVar('empno'),
								'allaownce' => $this->request->getVar('allaownce'),
								'deduction' => $this->request->getVar('deduction'),
								'pay_period' => $this->request->getVar('pay_period'),
								
							];
						
							$this->payroll_model->save($newdata);
						
							$message = "Successfully Salary added to the system";
							$session= session();
							$session->setFlashdata('sucess', $message);
							$data['profile']=$this->payroll_model->get_profile_empno($newdata['empno']);
							$data['payroll'] = $this->payroll_model->get_payroll($newdata['empno']);
							$data['attend'] = $this->attendance_model->get_attednace($newdata['empno']);
							$data['basic_salary'] = $data['profile']['basic_salary'];
							$data['allowances'] = $data['payroll']['allaownce'];
							$data['deduction'] = $data['payroll']['deduction'];
							$data['ot'] =1;//$data['attend']['OT'];
							$data['grosspay'] = ($data['basic_salary']+$data['allowances']+$data['ot']);
							$data['netsalary'] = ($data['grosspay']-$data['deduction']);



							//return redirect()->to('/admin/payroll/calcuate');
							 return view('admin/payroll/calculate_salary',$data);
						}
				}
                return view('admin/payroll/create',$data);
	}
        




	public function edit_user($id=null)
	{
					$data=[];
					if ($this->request->getMethod()=='post')
					{
						$rules=[
							'firstname'=> 'required|min_length[3]|max_length[20]',
							'lastname'=> 'required|min_length[3]|max_length[20]',
								'email'=> 'required|min_length[5]|max_length[50]|valid_email',
						];
						if ($this->request->getPost('password')!=''){
							$rules['password']= 'required|min_length[3]|max_length[20]';
							$rules['cpassword']= 'matches[password]';
						}
					 if (! $this->validate($rules)){
						$data['validation']= $this->validator;
					}
					 else
						{
						$newdata =
						[
									'id' => $id,
									'role' => $this->request->getPost('role'),
									'username'=>$this->request->getPost('username'),
									'firstname' => $this->request->getPost('firstname'),
									'lastname' => $this->request->getPost('lastname'),
									'email' => $this->request->getVar('email'),
									'slug' => url_title($this->request->getVar('email')),
									'update' => date('Y-m-d H:i:s',now()),
						];
			if ($this->request->getPost('password')!=''){
				$newdata['password']= $this->request->getPost('password');
			}
						$this->model->save($newdata);
						session()->setFlashdata('success', 'Sucessfully Updated');
						return redirect()->to('/user');
					 }
					}
					$data['user']=$this->model->where('id',$id)->first();
					return view("/payroll/edit",$data);
}


	
}
