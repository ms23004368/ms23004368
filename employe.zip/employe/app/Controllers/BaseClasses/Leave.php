<?php
namespace App\Controllers\BaseClasses;
use App\Controllers\BaseController;

use CodeIgniter\I18n\Time;
use App\Models\UserModel;
use App\Models\LeaveModel;
$pager = \Config\Services::pager();

class Leave extends BaseController
{

    private $model ;
    protected $logger;
    
    
    public function __construct()
    {
        helper('form');
        $this->model = new UserModel();
        $this->leave_model= new LeaveModel();
        helper('date');
        
        
    }

    public function index()
    {
      
        
        $data['users'] = $this->model->orderBy('id','DESC')->paginate(5);
        $data['pager'] = $this->model->pager;
        $data['title']="Users";
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("leave/view",$data);
    }


  public function leave_single_employee()
    
    {
              
        $data['users'] = $this->leave_model->get_employee_leave(session()->get('id'));
        $data['emp_dis'] = $this->model->getuser_from_id(session()->get('id'));
        
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("employee/leave/view",$data);
    }

   public function leave_requests()

    {

         

        $data['leave'] = $this->leave_model->get_leave_requests();
        $data['emp_dis'] = $this->model->getuser_from_id(session()->get('id'));
       // $this->logger->info('Retrieved all users from the database.', $data['leave']);
        return view("manager/leave/request_view",$data);
    }







    public function create_leave()
    {
        $data=[];
            if ($this->request->getMethod()=='post')
                {
                    $rules=
                        [
                            'date_apply'=> 'required|min_length[3]|max_length[20]',
                           
                            'reason'=> 'required|min_length[5]|max_length[255]',
                            
                            
                        ];
                    if (! $this->validate($rules))
                        {
                            $data['validation']= $this->validator;
                        }
                    else
                        {
                            $newdata =
                            [
                                'date_apply' => $this->request->getVar('date_apply'),
                                'type' => $this->request->getVar('type'),
                                'reason' => $this->request->getVar('reason'),
                                'empno' => $this->model->get_user_empno(session()->get('id')),
                                
                                
                            ];
                           
                            $this->leave_model->save($newdata);
                           
                            
                            
                            $message = "Sucesfully Apply for a leave ";
                            $session= session();
                            $session->setFlashdata('sucess', $message);
                            return redirect()->to('/employee/leave/view');
                        }
                }
                return view('employee/leave/create',$data);
    }
        




    public function edit_leave($id=null)
    {
                    $data=[];
                    if ($this->request->getMethod()=='post')
                    {
                        $rules=[
                             'date'=> 'required|min_length[3]|max_length[20]',
                            'type'=> 'required|min_length[3]|max_length[100]',
                            'reason'=> 'required|min_length[5]|max_length[50]',
                        ];

                       
                     if (! $this->validate($rules)){
                        $data['validation']= $this->validator;
                    }
                     else
                        {
                        $newdata =
                        [
                                'l_id' => $id,
                                'date' => $this->request->getVar('email'),
                                'type' => $this->request->getVar('password'),
                                'reason' => $this->request->getVar('reason'),
                        ];
           
                        $this->leave_model->save($newdata);
                        session()->setFlashdata('success', 'Sucessfully Updated');
                        return redirect()->to('/dashboard');
                     }
                    }
                    $data['user']=$this->leave_model->where('id',$id)->first();
                    return view("/leave/edit",$data);
}


  

public function manage_leaave_accept($id){

    session()->setFlashdata('sucess', 'Sucessfully leave accepted');
    $this->leave_model->change_approval($id,$is_approved=1,session()->get('id'));
    return redirect()->to('/manager/leave/leaverequest');

}


public function manager_leave_reject($id)
{
    session()->setFlashdata('sucess', 'Sucessfully leave rejected');
    $this->leave_model->change_approval($id,$is_approved=2,session()->get('id'));
    return redirect()->to('/manager/leave/leaverequest');
}

    
        
}
