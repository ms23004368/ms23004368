<?php namespace App\Controllers;

use App\Models\UserModel;
use App\Libraries\Send_Mail;
use CodeIgniter\I18n\Time;

class Login extends BaseController{
	// class attributes
	private $user_model;

	// consturct
	//======================================================================
	public function __construct(){
	// Helpers
	helper('form');
	helper('date');
	// create models from model classes
	$this->user_model = new UserModel();

	}
	// Index Page Home Page
	//======================================================================
	public function index(){
		$data=[];
		return  view("home/login",$data);
	}
	// Register session
	//======================================================================
	private function setUserSession($user){

			$data=[
				'id'=>$user['id'],
				'firstname'=>$user['firstname'],
				'lastname'=>$user['lastname'],
				'email'=>$user['email'],
				'isLogedIn' => true,
				'loginUser'=>$user['role'],
						];
			session()->set($data);
			return true;
	}
	// user login
	//======================================================================
	public function login(){
			helper('form');
			$data['title'] = "Users";
			if ($this->request->getMethod()=='post')
			{
			$rules=
				[
				'email'			=> 'required|min_length[6]|max_length[50]|valid_email|user_not_registred[email]',
				'password'	=> 'required|min_length[8]|max_length[255]|validateUser[email,password]',
				];
			$errors=
				[
				'password'	=> [ 'validateUser'	=> 'Email or Password don \'t match'],
				'email' 		=> ['user_not_registred'			=> "You are not registred user"]
							];
		 	 if (! $this->validate($rules,$errors))
			 {
						 $data['validation']= $this->validator;
			 }
			 else
			 {
	  			 $user= $this->user_model->getuser_from_email($this->request->getVar('email'));
					 $id = $user['id'];
					 
					 $this->setUserSession($user);

					 if ($user['role']=="Admin"){
					 	return redirect()->to('/admin/dashboard');

					 }elseif ($user['role']=="Employee")
					 {
					 		return redirect()->to('/employee/dashboard');
					 }elseif ($user['role']=="Manager"){
					 	return redirect()->to('/manager/dashboard');
					 }
					 
					 
		 	 	}
			}
				return  view("home/login",$data);
	}


				// Change password 	===================================================================
				// change password

				public function change_password(){
						$data=[];
						$data=[];
						if ($this->request->getMethod()=='post')
						{
			$rules=
							[
										'email'=> 'required|min_length[5]|max_length[50]|valid_email|is_notindb[email]',
							 ];
			if (! $this->validate($rules))
			{
										$data['validation']= $this->validator;
			}
				else
			{
					$data['user']=$this->user_model->getuser_from_email($this->request->getVar('email'));
				$newdata =
								[
									'id'=> $data['user']['id'],
									'password' => 'student@user',
								];
				$this->user_model->save($newdata);
				$preregid = "student@user";
				$gmail =$data['user']['email'];
				$subject = "your default password submited successfully";
				$body= "Yyour default password successfully submited and your password  is"." ".$preregid." ". "plase login to account your email and default password then you can change your password";
				$email_message=	$this->send_mail->user_reg_sendmail($gmail,$subject,$body);
				$message =$subject;
				$session= session();
				$session->setFlashdata('success', $message);
				return redirect()->to('/');
		 }
								 }
								 return  view("home/change_password",$data);
					}
				// user logout
				//======================================================================
				public function logout(){

					$newdata =
									[
										'id'=> session()->get('id'),
										'lastlogin' => date('Y-m-d H:i:s',now()),
									];
					$this->user_model->save($newdata);
						session()->destroy();
						return redirect()->to('/');

				}

}