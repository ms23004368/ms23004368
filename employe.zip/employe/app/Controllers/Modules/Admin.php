<?php

namespace App\Controllers\Modules;
use App\Controllers\BaseController;


use App\Controllers\BaseClasses\Attendance;
use App\Controllers\BaseClasses\Leave;
use App\Controllers\BaseClasses\Payroll;
use App\Controllers\BaseClasses\Users;
use App\Controllers\BaseClasses\Reports;
use App\Models\UserModel;
use App\Models\UserProfileModel;
use App\Models\LeaveModel;
use App\Models\AttendanceModel;
use App\Models\PayrollModel;
$pager = \Config\Services::pager();



/**

    Class AdminController 
    EmployeeController is responsible for handling operations related to employees.
    It extends the BaseController class, providing a convenient place for loading components
    and performing functions that are needed by all controllers.
    @extends BaseController
    **/

class Admin extends BaseController
{


    public function __construct()
    {
        helper('form');
        $this->user = new Users();
        $this->attendance = new Attendance();
        $this->payroll = new Payroll();
        $this->report = new Reports();
        $this->model = new UserModel();
        $this->employee= new UserProfileModel();
        $this->leave_model= new LeaveModel();
        $this->attendance_model = new AttendanceModel();
        $this->payroll_model = new PayrollModel();


        helper('date');
        
        
    }
    /*
    Display a employees dashboard
    @public
    */

    public function index()
    {
        $data['user'] = [session()->get('firstname'),session()->get('lastname')];
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');
        return  view("admin/admin_dashboard",$data);
    }



// edit employee profiel ========================================
    public function edit_profile(){


    }




public function system_users_view(){

    $data['users'] = $this->model->orderBy('id','DESC')->paginate(5);
        $data['pager'] = $this->model->pager;
        $data['title']="Users";
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("admin/users/view",$data);

    return view("admin/users/view",$data);

}


public function adimin_create_user(){
    $data=[];
  
    

}



public function user_attendance_view(){

    
        $data['attendances'] = $this->attendance_model ->get_attendace_users(); 
        //$this->model->orderBy('id','DESC')->paginate(5);
        //$data['pager'] = $this->model->pager;
      $data['title']="Users";
        //$this->logger->info('Retrieved all users from the database.', $data['attendance']);
        return view("admin/attendance/view",$data);

}

 public function adimin_create_attendance()
        {
            $data = [];

        $data['user'] = $this->model->get_users_empno();
            if ($this->request->getMethod()=='post')
                {
                    $rules=
                        [
                            'empno' => 'required',
                            'dateofattend'=> 'required',

                            'emp_status'=> 'required|',
                            'OT'=> 'required',
                            
                        // 'emp_status'=>
                        //  [
                        //      'label' => "Leave Validation",
                        //      'rules'=> 'is_allowed_status[empno]',
                        //      'errors'=> [
                        //                                      'is_allowed_status'=>"You have acquired all leave for this month "
                        //                           ]
                        //  ]

                        ];
                    if (! $this->validate($rules))
                        {
                            $data['validation']= $this->validator;
                        }
                    else
                        {
                            $newdata =
                            [
                                'empno' => $this->request->getVar('empno'),
                                'dateofattend' => $this->request->getVar('dateofattend'),
                                'emp_status' => $this->request->getVar('emp_status'),
                                'OT' => $this->request->getVar('OT'),
                                
                            ];
                            
                            $this->model->save($newdata);
                            
                            $message = "Sucessfully add attenance" ;
                            $session= session();
                            $session->setFlashdata('sucess', $message);
                            return redirect()->to('/admin/attendance/view');
                        }
                }
                return view('admin/attendance/create',$data);
    }



public function manage_payroll(){

    
       // $data['users']= $this->payroll_model->findAll()->paginate(5);
       // $this->orderBy('id','DESC')->findAll()
    
        
        $data['users'] = $this->payroll_model->get_payments_users(); //orderBy('p_id','DESC')->paginate(5);
        //$data['pager'] = $this->payroll_model->pager;
        $data['title']="Users";
        //$this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("admin/payroll/view",$data);

}


public function adimin_create_payroll(){

}


public function admin_reports(){

    
      // $data['users']= $this->model->findAll()->paginate(5);
       // $this->orderBy('id','DESC')->findAll()
        
        $data['users'] = $this->model->orderBy('id','DESC')->paginate(5);
        $data['pager'] = $this->model->pager;
        $data['title']="Users";
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("admin/report/view",$data);

}


// logout from the system 
    public function logout()
    {
        
    }



    public function view_user_profiels()
    {
         $data['user'] = $this->model->getuser_from_id($id);
         return view("admin/user/profile",$data);
    }

    
}
