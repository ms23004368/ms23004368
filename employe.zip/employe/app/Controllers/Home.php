<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\UserProfileModel;
class Home extends BaseController
{

    private $model ;
    protected $logger;
    
    
    public function __construct()
    {
        helper('form');
        $this->model = new UserModel();
        $this->employee= new UserProfileModel();
        helper('date');
        
        
    }

   


    public function index()
    {   
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');


        return  view("home/home",$data);
    }


    public function admin_dashboard()
    {   
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');


        return  view("admin/admin_dashboard",$data);
    }

        public function manager_dashboard()
    {   
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');


        return  view("manager/manager_dashboard",$data);
    }

public function employee_dashboard()
            {
                
        $data['user'] = [session()->get('firstname'),session()->get('lastname')];
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');
                return  view("employee/emp_dashboard",$data);
            }


public function view_user_profiels()
    {
         $data['user'] = $this->model->getuser_from_id(session()->get('id'));
         return view("home/user_profile",$data);
    }


}
