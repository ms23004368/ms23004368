<?php namespace App\Models;

use CodeIgniter\Model;

class UserProfileModel extends Model
{
    protected $table = 'user_profile';
    protected $primaryKey = 'empno';
    protected $allowedFields = ['uid','date_of_birth','apointment_date','depatment','created','profile_updated','qulifications','gender','nationalid','nic_img','basic_salary','address','emagency_contact','contact_person','designation','experience','job_status'];
 
  

    



        
          
}
