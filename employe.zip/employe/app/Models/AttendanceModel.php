<?php namespace App\Models;

use CodeIgniter\Model;

class AttendanceModel extends Model
{
    protected $table = 'attendance';
    protected $primaryKey = 'a_id';
    protected $allowedFields = ['empno','dateofattend','emp_status','OT'];
 
  


public function get_attendace_users()
        {
        
            $this->select('*');
              $this->join('user_profile','attendance.empno=user_profile.empno');
              $this->join('users','user_profile.uid=users.id');
              $this->select('users.firstname,users.lastname,user_profile.basic_salary,attendance.dateofattend,attendance.emp_status,attendance.OT');

             $users = $this->get()->getResultArray();
             return $users;
       
             
        }

public function get_attednace($empno){

        
        $this->where('attendance.empno',$empno);
        $ot_ot=$this->select('sum(attendance.OT)');
        return $ot_ot;
             
}

          
}
