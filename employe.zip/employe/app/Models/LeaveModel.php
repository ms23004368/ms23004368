<?php namespace App\Models;

use CodeIgniter\Model;

class LeaveModel extends Model
{
    protected $table = 'tbl_leave';
    protected $primaryKey = 'l_id';
    protected $allowedFields = ['empno','date_apply','is_approved','approved_by'];
   
public function get_employee_leave($id)
      {
            $this->select('*');
            $this->join('user_profile','tbl_leave.empno=user_profile.empno');
            $this->join('users','users.id=user_profile.uid');
            $this->select('tbl_leave.empno,tbl_leave.date_apply,tbl_leave.is_approved,tbl_leave.approved_by');
            $this->where('uid',$id);
               
            $leave = $this->get()->getResultArray();
            return $leave;

   }

 public function get_leave_requests()
 {
       $this->select('*');
        $this->join('user_profile','tbl_leave.empno=user_profile.empno');
            $this->join('users','users.id=user_profile.uid');
            $this->select('tbl_leave.empno,tbl_leave.date_apply,tbl_leave.is_approved,tbl_leave.approved_by');
        $leave = $this->get()->getResultArray();
            return $leave;
 }


  public function change_approval($id,$is_approved,$ar_by) 
       {
           $newdata=[];
            if ($id !=null){
            $newdata =
                    [
                      'l_id'  =>$id ,
                    'is_approved'=>$is_approved,
                      'approved_by'=>$ar_by
                    ];
         

           }
                     $this->save($newdata);


         }

          
}
